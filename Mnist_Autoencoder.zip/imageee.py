import numpy as np
import pandas as pd
import random


# Lire le fichier images_ideals.csv
def read_ideal_images(file_path):
    """
    Lit le fichier CSV contenant les représentations idéales des chiffres.
    :param file_path: Chemin du fichier CSV.
    :return: Un dictionnaire où les clés sont les chiffres (0-9) et les valeurs sont les représentations binaires.
    """
    df = pd.read_csv(file_path, header=None)
    ideal_images = {}
    for index, row in df.iterrows():
        # La dernière colonne contient le chiffre
        digit = int(row.iloc[-1])  # Utiliser iloc pour accéder à la dernière colonne
        # Les autres colonnes contiennent les données binaires
        binary_data = row.iloc[:-1].values.astype(int)
        ideal_images[digit] = binary_data
    return ideal_images


# Ajouter du bruit à une image
def add_noise(image, noise_level=0.1):
    """
    Ajoute du bruit à une image binaire.
    :param image: L'image binaire sous forme de tableau numpy.
    :param noise_level: Probabilité d'inverser un pixel (0 → 1 ou 1 → 0).
    :return: L'image bruitée.
    """
    noisy_image = image.copy()
    for i in range(len(noisy_image)):
        if random.random() < noise_level:
            noisy_image[i] = 1 - noisy_image[i]  # Inverser le pixel
    return noisy_image


# Générer un dataset de 1000 chiffres
def generate_dataset(ideal_images, num_samples=1000, noise_level=0.1):
    """
    Génère un dataset de chiffres bruités à partir des représentations idéales.
    :param ideal_images: Dictionnaire des représentations idéales.
    :param num_samples: Nombre total d'échantillons à générer.
    :param noise_level: Niveau de bruit à ajouter.
    :return: Un DataFrame contenant le dataset.
    """
    dataset = []
    labels = []
    digits = list(ideal_images.keys())

    for _ in range(num_samples):
        digit = random.choice(digits)  # Choisir un chiffre aléatoire
        ideal_image = ideal_images[digit]  # Obtenir la représentation idéale
        noisy_image = add_noise(ideal_image, noise_level)  # Ajouter du bruit
        dataset.append(noisy_image)
        labels.append(digit)

    # Convertir en DataFrame
    df = pd.DataFrame(dataset)
    df['label'] = labels
    return df


# Chemins des fichiers
input_file = 'images_ideals.csv'
output_file = 'data.csv'

# Lire les représentations idéales
ideal_images = read_ideal_images(input_file)

# Générer le dataset
dataset = generate_dataset(ideal_images, num_samples=1000, noise_level=0.1)

# Sauvegarder le dataset dans un fichier CSV
dataset.to_csv(output_file, index=False)
print(f"Dataset généré et sauvegardé dans '{output_file}'.")