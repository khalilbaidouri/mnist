import torch
import torch.nn as nn
import torch.optim as optim
import pandas as pd
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
import tkinter as tk
import numpy as np
import matplotlib.pyplot as plt
# 1. Visualiser quelques images du dataset
def visualize_dataset_samples(dataset, num_samples=5):
    fig, axes = plt.subplots(1, num_samples, figsize=(15, 3))
    for i in range(num_samples):
        image, label = dataset[i]  # Récupérer une image et son étiquette
        image = image.squeeze().numpy()  # Convertir en tableau numpy
        axes[i].imshow(image, cmap='gray')
        axes[i].set_title(f"Label: {label}")
        axes[i].axis('off')
    plt.suptitle("Échantillons du Dataset")
    plt.show()

# 2. Visualiser les reconstructions de l'autoencodeur
def visualize_autoencoder_reconstructions(autoencoder, dataset, num_samples=5):
    autoencoder.eval()  # Passer en mode évaluation
    fig, axes = plt.subplots(2, num_samples, figsize=(15, 6))
    for i in range(num_samples):
        image, label = dataset[i]
        image = image.unsqueeze(0)  # Ajouter une dimension de batch
        reconstructed, _ = autoencoder(image)  # Obtenir la reconstruction
        reconstructed = reconstructed.view(12, 6).detach().numpy()  # Convertir en tableau numpy
        original = image.view(12, 6).numpy()

        # Afficher l'image originale
        axes[0, i].imshow(original, cmap='gray')
        axes[0, i].set_title(f"Original (Label: {label})")
        axes[0, i].axis('off')

        # Afficher l'image reconstruite
        axes[1, i].imshow(reconstructed, cmap='gray')
        axes[1, i].set_title("Reconstruite")
        axes[1, i].axis('off')
    plt.suptitle("Reconstructions de l'Autoencodeur")
    plt.show()

# 3. Visualiser les prédictions du modèle de classification
def visualize_classification_predictions(model, dataset, num_samples=5):
    model.eval()  # Passer en mode évaluation
    fig, axes = plt.subplots(1, num_samples, figsize=(15, 3))
    for i in range(num_samples):
        image, label = dataset[i]
        image = image.unsqueeze(0)  # Ajouter une dimension de batch
        output = model(image)  # Obtenir la prédiction
        _, predicted = torch.max(output, 1)

        # Afficher l'image
        axes[i].imshow(image.view(12, 6).numpy(), cmap='gray')
        axes[i].set_title(f"Label: {label}, Prédit: {predicted.item()}")
        axes[i].axis('off')
    plt.suptitle("Prédictions du Modèle de Classification")
    plt.show()

# 4. Visualiser la fonction f(x, y) et la descente de gradient
def visualize_function_minimization():
    x_vals = np.linspace(-2, 2, 100)
    y_vals = np.linspace(-2, 2, 100)
    X, Y = np.meshgrid(x_vals, y_vals)
    Z = X**2 * np.cos(X)**2 + X**2 * np.sin(Y)**2 + Y**2

    plt.figure(figsize=(8, 6))
    plt.contourf(X, Y, Z, levels=50, cmap='viridis')
    plt.colorbar(label='f(x, y)')
    plt.xlabel('x')
    plt.ylabel('y')
    plt.title("Visualisation de la fonction f(x, y)")
    plt.show()

# Appeler les fonctions de visualisation
visualize_dataset_samples(train_dataset)
visualize_autoencoder_reconstructions(autoencoder, train_dataset)
visualize_classification_predictions(model, train_dataset)
visualize_function_minimization()