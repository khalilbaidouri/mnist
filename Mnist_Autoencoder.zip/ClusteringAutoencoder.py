import torch
import torch.nn as nn
import pandas as pd
from torch.utils.data import DataLoader
from sklearn.cluster import KMeans
from sklearn.manifold import TSNE
from sklearn.metrics import silhouette_score, adjusted_rand_score
import matplotlib.pyplot as plt
import seaborn as sns

# Charger les données depuis le CSV
class CSVDataset(torch.utils.data.Dataset):
    def __init__(self, csv_file):
        self.data = pd.read_csv(csv_file)

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        image = self.data.iloc[idx, :-1].values.astype('float32').reshape(12, 6)
        label = int(self.data.iloc[idx, -1])
        return torch.tensor(image).flatten(), label

# Charger les données
train_dataset = CSVDataset(csv_file='data.csv')
train_loader = DataLoader(train_dataset, batch_size=16, shuffle=False)

# Utiliser l'encodeur du VAE déjà entraîné
autoencoder = Autoencoder()
autoencoder.load_state_dict(torch.load('autoencoder.pth'))  # Assurez-vous de sauvegarder le modèle au préalable
autoencoder.eval()

latent_features = []
true_labels = []

with torch.no_grad():
    for images, labels in train_loader:
        _, latent = autoencoder(images)
        latent_features.append(latent)
        true_labels.extend(labels.numpy())

latent_features = torch.cat(latent_features).numpy()

# Appliquer le clustering KMeans
kmeans = KMeans(n_clusters=10, random_state=42)
cluster_labels = kmeans.fit_predict(latent_features)

# Évaluation des clusters
silhouette = silhouette_score(latent_features, cluster_labels)
ari = adjusted_rand_score(true_labels, cluster_labels)
print(f"Silhouette Score: {silhouette:.4f}")
print(f"Adjusted Rand Index: {ari:.4f}")

# Visualisation avec t-SNE
tsne = TSNE(n_components=2, random_state=42)
latent_2d = tsne.fit_transform(latent_features)

plt.figure(figsize=(8, 6))
sns.scatterplot(x=latent_2d[:, 0], y=latent_2d[:, 1], hue=cluster_labels, palette='tab10')
plt.title('Visualisation des clusters avec t-SNE')
plt.show()