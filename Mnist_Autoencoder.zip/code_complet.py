import torch
import torch.nn as nn
import torch.optim as optim
import pandas as pd
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
import tkinter as tk
import numpy as np
import matplotlib.pyplot as plt

# 1. Créer un Dataset personnalisé pour charger les données à partir du CSV
class CSVDataset(Dataset):
    def __init__(self, csv_file, transform=None):
        self.data = pd.read_csv(csv_file)
        self.transform = transform

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        image = self.data.iloc[idx, :-1].values  # Toutes les colonnes sauf la dernière
        label = int(self.data.iloc[idx, -1])    # Dernière colonne comme étiquette
        image = image.astype('float32').reshape(12, 6)

        if self.transform:
            image = self.transform(image)

        return image, label

# 2. Définir les transformations
transform = transforms.Compose([
    transforms.ToTensor(),  # Convertir en tenseur
])

# 3. Charger les données depuis le fichier CSV
train_dataset = CSVDataset(csv_file='data.csv', transform=transform)
train_loader = DataLoader(train_dataset, batch_size=16, shuffle=True)

# 4. Définir l'autoencodeur
class Autoencoder(nn.Module):
    def __init__(self):
        super(Autoencoder, self).__init__()
        # Encodeur
        self.encoder = nn.Sequential(
            nn.Linear(12 * 6, 64),
            nn.ReLU(),
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Linear(32, 10)  # Espace latent (10 dimensions)
        )
        # Décodeur
        self.decoder = nn.Sequential(
            nn.Linear(10, 32),
            nn.ReLU(),
            nn.Linear(32, 64),
            nn.ReLU(),
            nn.Linear(64, 12 * 6)  # Reconstruction
        )

    def forward(self, x):
        x = x.view(-1, 12 * 6)  # Aplatir l'image
        latent = self.encoder(x)  # Encoder
        reconstructed = self.decoder(latent)  # Decoder
        return reconstructed, latent

# 5. Définir l'autoencodeur variationnel (VAE)
class VAE(nn.Module):
    def __init__(self):
        super(VAE, self).__init__()
        # Encodeur
        self.encoder = nn.Sequential(
            nn.Linear(12 * 6, 64),
            nn.ReLU(),
            nn.Linear(64, 32),
            nn.ReLU()
        )
        self.fc_mu = nn.Linear(32, 10)  # Moyenne de l'espace latent
        self.fc_logvar = nn.Linear(32, 10)  # Log-variance de l'espace latent

        # Décodeur
        self.decoder = nn.Sequential(
            nn.Linear(10, 32),
            nn.ReLU(),
            nn.Linear(32, 64),
            nn.ReLU(),
            nn.Linear(64, 12 * 6)
        )

    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std

    def forward(self, x):
        x = x.view(-1, 12 * 6)
        h = self.encoder(x)
        mu, logvar = self.fc_mu(h), self.fc_logvar(h)
        z = self.reparameterize(mu, logvar)
        reconstructed = self.decoder(z)
        return reconstructed, mu, logvar

# 6. Définir le modèle de classification
class ImprovedModel(nn.Module):
    def __init__(self):
        super(ImprovedModel, self).__init__()
        self.fc1 = nn.Linear(12 * 6, 20)  # Entrée de 12x6 pixels
        self.fc2 = nn.Linear(20, 10)      # Couche cachée avec 20 neurones
        self.fc3 = nn.Linear(10, 10)      # Couche de sortie avec 10 neurones
        self.relu = nn.ReLU()

    def forward(self, x):
        x = x.view(-1, 12 * 6)  # Aplatir l'image en un vecteur de 12x6
        x = self.relu(self.fc1(x))
        x = self.relu(self.fc2(x))
        x = self.fc3(x)
        return x

# 7. Entraîner l'autoencodeur
autoencoder = Autoencoder()
criterion_ae = nn.MSELoss()  # Perte de reconstruction
optimizer_ae = optim.Adam(autoencoder.parameters(), lr=0.001)

epochs = 10
for epoch in range(epochs):
    autoencoder.train()
    running_loss = 0.0

    for images, _ in train_loader:  # On ignore les étiquettes
        optimizer_ae.zero_grad()
        reconstructed, _ = autoencoder(images)
        loss = criterion_ae(reconstructed, images.view(-1, 12 * 6))
        loss.backward()
        optimizer_ae.step()

        running_loss += loss.item()

    print(f"Autoencodeur - Époque {epoch + 1}/{epochs}, Perte : {running_loss / len(train_loader):.4f}")

# 8. Entraîner le VAE
vae = VAE()
criterion_vae = nn.MSELoss()
optimizer_vae = optim.Adam(vae.parameters(), lr=0.001)

for epoch in range(epochs):
    vae.train()
    running_loss = 0.0

    for images, _ in train_loader:
        optimizer_vae.zero_grad()
        reconstructed, mu, logvar = vae(images)
        loss = criterion_vae(reconstructed, images.view(-1, 12 * 6)) - 0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp())
        loss.backward()
        optimizer_vae.step()

        running_loss += loss.item()

    print(f"VAE - Époque {epoch + 1}/{epochs}, Perte : {running_loss / len(train_loader):.4f}")

# 9. Entraîner le modèle de classification
model = ImprovedModel()
criterion_cls = nn.CrossEntropyLoss()
optimizer_cls = optim.Adam(model.parameters(), lr=0.01)

train_losses = []
train_accuracies = []

for epoch in range(epochs):
    model.train()
    running_loss = 0.0

    for images, labels in train_loader:
        optimizer_cls.zero_grad()
        outputs = model(images)
        loss = criterion_cls(outputs, labels)
        loss.backward()
        optimizer_cls.step()

        running_loss += loss.item()

    epoch_loss = running_loss / len(train_loader)
    train_losses.append(epoch_loss)

    # Calculer la précision
    correct = 0
    total = 0
    with torch.no_grad():
        for images, labels in train_loader:
            outputs = model(images)
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

    accuracy = 100 * correct / total
    train_accuracies.append(accuracy)

    print(f"Classification - Époque {epoch + 1}/{epochs}, Perte : {epoch_loss:.4f}, Précision : {accuracy:.2f}%")

# 10. Minimisation de la fonction f(x, y) avec la descente de gradient
def f(x, y):
    return x**2 * torch.cos(x)**2 + x**2 * torch.sin(y)**2 + y**2

# Initialiser les variables
x = torch.tensor(1.0, requires_grad=True)  # Point initial pour x
y = torch.tensor(1.0, requires_grad=True)  # Point initial pour y

# Taux d'apprentissage
learning_rate = 0.01

# Descente de gradient
for i in range(1000):
    loss = f(x, y)
    loss.backward()

    with torch.no_grad():
        x -= learning_rate * x.grad
        y -= learning_rate * y.grad

    x.grad.zero_()
    y.grad.zero_()

    if i % 100 == 0:
        print(f"Iteration {i}: x = {x.item()}, y = {y.item()}, f(x, y) = {loss.item()}")

print(f"Minimum trouvé : x = {x.item()}, y = {y.item()}, f(x, y) = {loss.item()}")

# 11. Fonction pour dessiner ou effacer sur la grille en glissant
def draw(event, canvas, grid, rows, cols, cell_size):
    col = event.x // cell_size
    row = event.y // cell_size
    if 0 <= row < rows and 0 <= col < cols:
        index = row * cols + col
        if grid[index] == 0:
            # Remplir la cellule en noir
            canvas.create_rectangle(
                col * cell_size, row * cell_size,
                (col + 1) * cell_size, (row + 1) * cell_size,
                fill="black", outline="black"
            )
            grid[index] = 1

# Fonction pour effacer la grille
def clear_grid(canvas, grid, rows, cols, cell_size):
    canvas.delete("all")
    for i in range(rows):
        for j in range(cols):
            canvas.create_rectangle(
                j * cell_size, i * cell_size,
                (j + 1) * cell_size, (i + 1) * cell_size,
                outline="black", fill="white"
            )
    grid[:] = [0] * (rows * cols)

# Fonction pour prédire le chiffre dessiné
def predict_digit(grid, rows, cols):
    grid_tensor = torch.tensor(grid, dtype=torch.float32).view(1, -1)
    with torch.no_grad():
        outputs = model(grid_tensor)
        _, predicted = torch.max(outputs, 1)
    return predicted.item()

# Interface graphique avec tkinter
def create_grid_app(rows=12, cols=6, cell_size=40):
    root = tk.Tk()
    root.title("Grille Interactive pour Dessiner un Chiffre")

    # Créer un vecteur pour stocker l'état de chaque cellule
    grid = [0] * (rows * cols)

    # Créer le canevas pour dessiner
    canvas = tk.Canvas(root, width=cols * cell_size, height=rows * cell_size)
    canvas.pack()

    # Dessiner la grille initiale
    for i in range(rows):
        for j in range(cols):
            canvas.create_rectangle(
                j * cell_size, i * cell_size,
                (j + 1) * cell_size, (i + 1) * cell_size,
                outline="black", fill="white"
            )

    # Lier l'événement de clic et de glissement à la fonction draw
    canvas.bind("<Button-1>", lambda event: draw(event, canvas, grid, rows, cols, cell_size))
    canvas.bind("<B1-Motion>", lambda event: draw(event, canvas, grid, rows, cols, cell_size))

    # Bouton pour prédire le chiffre
    predict_button = tk.Button(root, text="Prédire le chiffre", command=lambda: result_label.config(text=f"Chiffre prédit : {predict_digit(grid, rows, cols)}"))
    predict_button.pack()

    # Bouton pour effacer la grille
    clear_button = tk.Button(root, text="Effacer la grille", command=lambda: clear_grid(canvas, grid, rows, cols, cell_size))
    clear_button.pack()

    # Label pour afficher la prédiction
    result_label = tk.Label(root, text="Chiffre prédit : ")
    result_label.pack()

    # Lancer la boucle principale de l'application
    root.mainloop()

# Lancer l'application
create_grid_app()